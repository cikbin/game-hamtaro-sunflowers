import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class back here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class back extends World
{
public static int score;
    /**
     *
     * Constructor for objects of class back.
     * 
     */
    public back()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        addObject(new hamtaro(), 200, 300);
        aturLetak();
        addObject(new score(), 520, 30);
        score=0;
    }

    public void aturLetak()
    {
        for(int i=0; i<10; i++){
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = Greenfoot.getRandomNumber(getHeight());
            addObject(new sunflow(), x, y);
            addObject(new jamur(), y, x);
        }
    }
}