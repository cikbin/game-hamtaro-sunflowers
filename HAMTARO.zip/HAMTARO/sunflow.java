import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class sunflow here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class sunflow extends Actor
{
    /**
     * Act - do whatever the sunflow wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
   private GreenfootImage[] gambarsunflow=new GreenfootImage[2];
    private int frame=0, jeda=5, num=0;
    public sunflow()
    {
        for (int i=0;i<2;i++){
            gambarsunflow[i]=new GreenfootImage("sunflow"+i+".png");
        }
        setImage(gambarsunflow[1]);
    }

    public void act() 
    {
        setImage(gambarsunflow[frame]);
        frame++;
        if(frame>=2){
            frame=0;
        }
    }

    private void gerak(){
        if(jeda==0){
            jeda=5;
        }

        if(jeda==1){
            setImage(gambarsunflow[num]);
            num++;}
        if(num>=gambarsunflow.length){
            num=0;
        }
        setLocation(getX(),getY());
        if(jeda>0){
            jeda--;
        }

    }    
}