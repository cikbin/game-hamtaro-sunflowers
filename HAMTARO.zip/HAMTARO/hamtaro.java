import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class hamtaro here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class hamtaro extends Actor
{
    /**
     * Act - do whatever the hamtaro wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private GreenfootImage[] gambarhamtaro=new GreenfootImage[8];
    private int frame=0, jeda=5, num=0;

    public void act()
    {
        cekKunci();
        lihatsunflow();
        sedotsunflow();

        sedotjamur();
    }

    public hamtaro()
    {
        for (int i=0;i<8;i++){
            gambarhamtaro[i]=new GreenfootImage("hamtaro"+i+".png");
        }
        setImage(gambarhamtaro[0]);
    }

    public void cekKunci()
    {

        setImage(gambarhamtaro[frame]);
        frame++;
        if(frame>=8){
            frame=0;
        }

        {
            if(Greenfoot.isKeyDown("right")){
                turn(5);
            }
            else if(Greenfoot.isKeyDown("left")){
                turn(-5);
            }
            else if(Greenfoot.isKeyDown("up")){
                move(5);
            }
            else if(Greenfoot.isKeyDown("down")){
                move(-5);
            }
        }
    }

    private void gerak(){
        if(jeda==0){
            jeda=5;
        }

        if(jeda==1){
            setImage(gambarhamtaro[num]);
            num++;
        }
        if(num>=gambarhamtaro.length){
            num=0;
        }
        setLocation(getX(),getY());
        if(jeda>0){
            jeda--;
        }

    } 

    public boolean lihatsunflow()
    {
        Actor sunflow =getOneObjectAtOffset(0,0, sunflow.class);
        return sunflow!=null;
    }

    public void sedotsunflow()
    {
        Actor sunflow = getOneObjectAtOffset(30,30, sunflow.class);
        if(sunflow!=null) {
            getWorld().removeObject(sunflow);
            back.score++;
            if (back.score >= 10){
                Greenfoot.stop();
                getWorld().addObject(new win (), 265, 200);
            }
        }
    }

    public void sedotjamur()
    {
        Actor jamur = getOneObjectAtOffset(0,0, jamur.class);
        if(jamur!=null) {
            getWorld().removeObject(jamur);
            back.score--;
            if (back.score==-1){
                Greenfoot.stop();
                getWorld().addObject(new kalah (), 290, 200);
            }
        }
    }

}

